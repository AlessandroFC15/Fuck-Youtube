export const mirrorApiUrl = 'https://fuck-youtube-server.herokuapp.com'
