# Fuck-Youtube 

[![Build Status](https://travis-ci.org/AlessandroFC15/Fuck-Youtube.svg?branch=master)](https://travis-ci.org/AlessandroFC15/Fuck-Youtube) 

<p><img width="20" src="https://ffp4g1ylyit3jdyti1hqcvtb-wpengine.netdna-ssl.com/firefox/files/2017/12/firefox-logo-300x310.png"> <a href="https://addons.mozilla.org/en-US/firefox/addon/f-ck-youtube/">Available for Firefox</a></p>

A browser extension that allows the user to watch YouTube videos that are blocked for a certain region.

<p align="center">
  <img width="600" src="https://raw.githubusercontent.com/AlessandroFC15/Fuck-Youtube/master/assets/pictures/tiles/920x680/920x680.png">
</p>

## Project Info

This project uses [Semantic Versioning](https://semver.org/).

- **Current Version**: 1.0.0 (Latest version only available on Firefox)

- **Code Style**: [Crockford](http://javascript.crockford.com/code.html), checked by [JSCS](http://jscs.info/)

- **Code Quality Tool**: [JSHint](http://jshint.com/about/)

<p align="center">
  <img height="180" src="https://github.com/AlessandroFC15/Fuck-Youtube/blob/master/assets/pictures/tiles/ideia4.png?raw=true">
</p>

### Installation:

    git clone https://github.com/AlessandroFC15/Fuck-Youtube.git

    # in case you don't have webpack yet:
    sudo npm install -g webpack

### Build instructions:

To install dependencies:

    cd Fuck-Youtube
    npm install

Then to start a developing session (with watch), run:

    npm start

To build CRX file and source code zip file for production:

    ./scripts/prepare_release.sh
    
## Dependencies

In order to find an alternative url for blocked videos, this extensions uses an API offered 
by [fuck-youtube-server](https://github.com/AlessandroFC15/fuck-youtube-server), which is also open-source. 

## Featured On

- **The Next Web**

<a href="https://thenextweb.com/google/2017/11/29/chrome-google-youtube-region-video/"><img height="40" src="https://thenextweb.com/wp-content/themes/cyberdelia/assets/img/logo-tnw-white.svg"></a>

> <a href="https://thenextweb.com/google/2017/11/29/chrome-google-youtube-region-video/">This free Chrome extension lets you watch geo-blocked videos on YouTube</a>

-----

- **Phonandroid**

<a href="http://www.phonandroid.com/google-chrome-extension-gratuite-permet-regarder-videos-youtube-interdites-france.html/"><img height="40" src="https://pbs.twimg.com/profile_images/756458420652347392/A9jW0Qiy.jpg"></a>

> <a href="http://www.phonandroid.com/google-chrome-extension-gratuite-permet-regarder-videos-youtube-interdites-france.html">Google Chrome : cette extension gratuite permet de regarder les vidéos YouTube interdites en France</a>

-----

- **Tecnomanía**

<a href="https://tecnomania.com.ve/index.php/2017/11/29/como-ver-videos-de-youtube-bloqueados-en-espana-o-al-viajar-al-extranjero/"><img height="40" src="https://tecnomania.com.ve/wp-content/uploads/2017/07/tecnomania-logo-02.png"></a>

> <a href="https://tecnomania.com.ve/index.php/2017/11/29/como-ver-videos-de-youtube-bloqueados-en-espana-o-al-viajar-al-extranjero/">Cómo ver vídeos de YouTube bloqueados en España o al viajar al extranjero</a>

-----

- **omicrono**

<a href="http://omicrono.elespanol.com/2017/11/ver-videos-bloqueados-en-youtube/"><img height="40" src="http://omicrono.elespanol.com/wp-content/themes/Omicrono/images/logo.png"></a>

> <a href="http://omicrono.elespanol.com/2017/11/ver-videos-bloqueados-en-youtube/">Ver vídeos bloqueados por región en Youtube sin usar una VPN es posible con una extensión</a>



